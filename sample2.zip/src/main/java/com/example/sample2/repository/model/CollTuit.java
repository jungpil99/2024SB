package com.example.sample2.repository.model;

import lombok.Data;

@Data
public class CollTuit {

	private Integer collegeId;
	private Integer amount;
}
