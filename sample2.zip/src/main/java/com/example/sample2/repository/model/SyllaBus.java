package com.example.sample2.repository.model;

import lombok.Data;

@Data
public class SyllaBus {

	private int subjectId;
	private String overview;
	private String objective;
	private String textbook;
	private String program;
	
}
