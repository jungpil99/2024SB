package com.example.sample2.repository.model;

import lombok.Data;

@Data
public class User {

	private Integer id;
	private String password;
	private String userRole;

}
