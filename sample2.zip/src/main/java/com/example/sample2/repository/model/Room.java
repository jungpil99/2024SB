package com.example.sample2.repository.model;

import lombok.Data;

@Data
public class Room {

	private String id;
	private Integer collegeId;
	
}
