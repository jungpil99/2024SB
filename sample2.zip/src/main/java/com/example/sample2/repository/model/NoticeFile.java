package com.example.sample2.repository.model;

import lombok.Data;

@Data
public class NoticeFile {

	private Integer noticeId;
	private String originFilename;
	private String uuidFilename;
}
