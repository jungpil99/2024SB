package com.example.sample2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Sample2Application {

    public static void main(String[] args) {
        SpringApplication.run(Sample2Application.class, args);
    }

}
