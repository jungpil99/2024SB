package com.example.sample2.dto.response;

import lombok.Data;

@Data
public class StuSubSumGradesDto {

	private Integer studentId;
	private Integer sumGrades;
	
}
